public class NoUpperAlphaException extends Exception{ 

    public NoUpperAlphaException(){}
    public NoUpperAlphaException(String message) {
        super(message);
    }

}