public class InvalidSequenceException extends Exception{
    public InvalidSequenceException(){

    }
    public InvalidSequenceException(String message){
        super(message);
    }
}