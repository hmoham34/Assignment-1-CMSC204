/*   
Hussain Mohammad

*/



import java.util.ArrayList;
import java.util.regex.Pattern;

public class PasswordCheckerUtility {

    // Validates the password against all criteria
    public static boolean isValidPassword(String password) throws LengthException, NoUpperAlphaException,
            NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException, UnmatchedException {
        
        checkLength(password);
        checkUpperCase(password);
        checkLowerCase(password);
        checkDigit(password);
        checkSpecialCharacter(password);
        checkInvalidSequence(password);
        
        return true;
    }

    // Check for weak password (between 6 and 9 characters)
    public static boolean isWeakPassword(String password) throws WeakPasswordException {
        int length = password.length();
        if (length >= 6 && length <= 9) {
            throw new WeakPasswordException("Weak password - contains fewer than 10 characters.");
        }
        return false;
    }

    // Retrieves a list of invalid passwords with their respective error messages
    public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
        ArrayList<String> invalidPasswords = new ArrayList<>();

        for (String password : passwords) {
            try {
                isValidPassword(password);
            } catch (Exception e) {
                invalidPasswords.add(password + " " + e.getMessage());
            }
        }
        return invalidPasswords;
    }

    // Private method to validate the minimum length of the password
    private static void checkLength(String password) throws LengthException {
        if (password.length() < 6) {
            throw new LengthException("The password must be at least 6 characters long.");
        }
    }

    // Private method to verify the presence of an uppercase letter
    private static void checkUpperCase(String password) throws NoUpperAlphaException {
        if (password.equals(password.toLowerCase())) {
            throw new NoUpperAlphaException("The password must contain at least one uppercase character.");
        }
    }

    // Private method to verify the presence of a lowercase letter
    private static void checkLowerCase(String password) throws NoLowerAlphaException {
        if (password.equals(password.toUpperCase())) {
            throw new NoLowerAlphaException("The password must contain at least one lowercase character.");
        }
    }

    // Private method to verify the presence of a digit
    private static void checkDigit(String password) throws NoDigitException {
        if (!password.matches(".*\\d.*")) {
            throw new NoDigitException("The password must contain at least one digit.");
        }
    }

    // Private method to verify the presence of a special character
    private static void checkSpecialCharacter(String password) throws NoSpecialCharacterException {
        if (password.matches("[a-zA-Z0-9]*")) {
            throw new NoSpecialCharacterException("The password must contain at least one special character.");
        }
    }

    // Private method to ensure no character appears more than twice consecutively
    private static void checkInvalidSequence(String password) throws InvalidSequenceException {
        for (int i = 0; i < password.length() - 2; i++) {
            if (password.charAt(i) == password.charAt(i + 1) && password.charAt(i + 1) == password.charAt(i + 2)) {
                throw new InvalidSequenceException("The password cannot have more than two consecutive identical characters.");
            }
        }
    }
    
    // Compare two passwords for equality
    public static boolean comparePasswords(String password1, String password2) throws UnmatchedException {
        if (!password1.equals(password2)) {
            throw new UnmatchedException("Passwords do not match.");
        }
        return true;
    }
}
